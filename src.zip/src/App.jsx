import { useState } from "react";
import Searchbar from "./Components/Searchbar";
import FilterBox from "./Components/FilterBox";
import ReptilePost from "./Components/ReptilePost";
import ReptileDetailModal from "./Components/ReptileDetailModal";

import musk from "./assets/musk.jpg";

function App() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);

  const pets = [
    { species: "屋頂龜", price: 100, size: "Small", imageUrl: musk },
    { species: "球蟒", price: 320, size: "Large", imageUrl: musk },
    { species: "豹紋守宮", price: 220, size: "Medium", imageUrl: musk },
    { species: "綠鬣蜥", price: 450, size: "Large", imageUrl: musk },
    { species: "紅耳龜", price: 180, size: "Small", imageUrl: musk },
  ];

  const filteredPets = pets.filter((pet) =>
    pet.species.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <>
      <Searchbar onSearch={setQuery} />

      <div className="market-container">
        <FilterBox />

        <div className="grid">
          {filteredPets.map((pet, i) => (
            <ReptilePost
              key={i}
              props={pet}
              onClick={setSelected}
            />
          ))}
        </div>
      </div>

      {selected && (
        <ReptileDetailModal
          reptile={selected}
          onClose={() => setSelected(null)}
        />
      )}
    </>
  );
}

export default App;
