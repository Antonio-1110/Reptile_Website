export default function ReptileDetailModal({ reptile, onClose }) {
  if (!reptile) return null;

  return (
    <div className="detail-backdrop" onClick={onClose}>
      <div className="detail-modal" onClick={(e) => e.stopPropagation()}>
        <div className="detail-image">
          <img src={reptile.imageUrl} alt={reptile.species} />
        </div>

        <div className="detail-info">
          <div className="detail-title">{reptile.species}</div>
          <div>Size: {reptile.size}</div>
          <div className="detail-price">${reptile.price}</div>

          <div className="detail-actions">
            <button
              className="add-cart"
              onClick={() => alert("Added to cart")}
            >
              Add to Cart
            </button>

            <button
              className="bargain"
              onClick={() => alert("Bargain requested")}
            >
              Bargain
            </button>

            <button
              className="buy-now"
              onClick={() => alert("Proceed to checkout")}
            >
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
