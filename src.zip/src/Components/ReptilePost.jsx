export default function ReptilePost({ props, onClick }) {
  return (
    <div className="reptilepost" onClick={() => onClick(props)}>
      <img src={props.imageUrl} alt={props.species} />

      <div className="postinfo">
        <div>{props.species}</div>
        <div>Size: {props.size}</div>
        <div className="price">${props.price}</div>
      </div>
    </div>
  );
}
